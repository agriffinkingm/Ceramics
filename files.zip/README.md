# Ceramics Website

A simple, elegant website to showcase ceramic artwork with a gallery and available pieces section.

## Features

- **Gallery**: Display your ceramic pieces in a beautiful grid layout
- **Available Pieces**: Showcase pieces currently for sale with pricing and descriptions
- **Responsive Design**: Works beautifully on desktop, tablet, and mobile devices
- **Elegant Aesthetics**: Earthy color palette and refined typography perfect for ceramics

## Getting Started

### Viewing Locally

Simply open `index.html` in your web browser to view the website.

### Deploying with GitHub Pages

1. Go to your repository settings
2. Navigate to "Pages" in the left sidebar
3. Under "Source", select "main" branch
4. Click "Save"
5. Your site will be live at `https://[your-username].github.io/[repository-name]`

## Customization

### Adding Your Images

Replace the placeholder content in `index.html`:

**For Gallery Images:**
Replace the placeholder `<div class="gallery-item">` with:
```html
<div class="gallery-item">
    <img src="images/your-image.jpg" alt="Description">
    <div class="gallery-overlay">
        <h3>Piece Name</h3>
        <p>Brief description</p>
    </div>
</div>
```

**For Available Pieces:**
Update the piece cards with your information:
```html
<div class="piece-card">
    <div class="piece-image">
        <img src="images/your-piece.jpg" alt="Piece name">
    </div>
    <div class="piece-info">
        <h3>Your Piece Name</h3>
        <div class="piece-meta">
            <span>Stoneware</span>
            <span>•</span>
            <span>8" × 6"</span>
        </div>
        <p class="piece-description">
            Your description here.
        </p>
        <div class="piece-price">$150</div>
        <button class="contact-btn">Inquire</button>
    </div>
</div>
```

### Organizing Images

Create an `images` folder in your repository and upload your ceramic photos there. Reference them using `images/filename.jpg` in the src attributes.

### Changing Colors

The color scheme is defined at the top of the CSS using CSS variables. Update these in the `:root` section:
- `--clay-warm`: Warm beige background
- `--terracotta`: Accent color
- `--stone`: Dark text color
- `--ivory`: Background color

## File Structure

```
ceramics-website/
├── index.html          # Main website file
├── README.md          # This file
└── images/            # Create this folder for your photos
    ├── piece1.jpg
    ├── piece2.jpg
    └── ...
```

## License

Feel free to use and modify this template for your own ceramics website.
